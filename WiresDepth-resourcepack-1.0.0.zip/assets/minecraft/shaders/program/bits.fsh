#version 150
uniform sampler2D InSampler; in vec2 texCoord; out vec4 fragColor; void main(){vec4 c=texture(InSampler,texCoord);fragColor=vec4(floor(c.rgb*8.0)/8.0,c.a);}
