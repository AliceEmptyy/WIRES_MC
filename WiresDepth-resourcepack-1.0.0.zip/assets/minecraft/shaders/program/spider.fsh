#version 150
uniform sampler2D InSampler; in vec2 texCoord; out vec4 fragColor; void main(){vec2 p=texCoord-.5;float a=atan(p.y,p.x)+sin(length(p)*30.0)*.05;vec2 q=vec2(cos(a),sin(a))*length(p)+.5;fragColor=texture(InSampler,q);}
