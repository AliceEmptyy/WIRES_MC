#version 150
uniform sampler2D InSampler; in vec2 texCoord; out vec4 fragColor; void main(){vec2 p=texCoord-.5;float d=.004;fragColor=vec4(texture(InSampler,texCoord+normalize(p)*d).r,texture(InSampler,texCoord).g,texture(InSampler,texCoord-normalize(p)*d).b,1);}
