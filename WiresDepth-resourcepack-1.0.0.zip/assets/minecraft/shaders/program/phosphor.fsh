#version 150
uniform sampler2D InSampler; in vec2 texCoord; out vec4 fragColor; void main(){vec4 c=texture(InSampler,texCoord);fragColor=vec4(c.rgb*vec3(1.05,.92,.82),c.a);}
